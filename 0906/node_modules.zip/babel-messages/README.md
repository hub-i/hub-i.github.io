# babel-messages

> Collection of debug messages used by Babel.

## Install

```sh
npm install --save-dev babel-messages
```

## Usage

```js
import * as messages from 'babel-messages';

messages.get('tailCallReassignmentDeopt');
// > "Function reference has been..."
```
