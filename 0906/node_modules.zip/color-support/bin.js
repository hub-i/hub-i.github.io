#!/usr/bin/env node
var colorSupport = require('./')({alwaysReturn: true })
console.log(JSON.stringify(colorSupport, null, 2))
