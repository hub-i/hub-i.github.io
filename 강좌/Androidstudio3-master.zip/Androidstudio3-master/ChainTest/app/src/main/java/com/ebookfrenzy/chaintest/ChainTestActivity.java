package com.ebookfrenzy.chaintest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ChainTestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chain_test);
    }
}
