/**
 * Created by bagjeongtae on 2017. 7. 16..
 */
for(var i = 0 ; i< 10 ; i++){
    for(var j = 0 ; j < 10 ; j++){
        console.log(i + ' * ' + j + '=' + i * j);
    }
}