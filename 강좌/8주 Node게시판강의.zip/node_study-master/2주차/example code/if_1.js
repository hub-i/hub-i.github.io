/**
 * Created by bagjeongtae on 2017. 7. 16..
 */

// example1
if(0){
    console.log('hello1');
}
if(1){
    console.log('world2');
}

if(1){
    console.log('hello3');
}
if(0){
    console.log('world4');
}

