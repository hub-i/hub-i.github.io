function sum(a, b, c){
	console.log('test123');
}
module.exports = {
	sum: sum
}
