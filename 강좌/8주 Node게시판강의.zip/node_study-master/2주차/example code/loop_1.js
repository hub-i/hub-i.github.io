/**
 * Created by bagjeongtae on 2017. 7. 16..
 */

for(var i = 0 ; i< 10 ; i++){
    console.log('hello world');
}