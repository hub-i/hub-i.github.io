/**
 * Created by bagjeongtae on 2017. 7. 16..
 */

// example1

if(1){
    console.log('hello world1');
}else if(1){
    console.log('hello world2');

}else if(1){
    console.log('hello world3');
}else{
    console.log('last')
}

// example2

if(0){
    console.log('hello world1');
}else if(1){
    console.log('hello world2');

}else if(1){
    console.log('hello world3');
}else{
    console.log('last')
}