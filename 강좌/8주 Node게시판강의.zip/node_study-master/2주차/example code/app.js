"use strict";
var test = require('./sum.js');

test.sum(1)
a = 10
