/**
 * Created by bagjeongtae on 2017. 7. 16..
 */
// example3
if(0){
    console.log('hello world1');
}else if(0){
    console.log('hello world2');

}else if(0){
    console.log('hello world3');
}else{
    console.log('last')
}