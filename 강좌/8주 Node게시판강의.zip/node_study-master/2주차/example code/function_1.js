/**
 * Created by bagjeongtae on 2017. 7. 16..
 */

function test(){          // 함수정의
    console.log('test');
}

function test1(a, b, c){  // 함수정의
    console.log(a, b, c);
}

test();          // 함수호출
test1(1);        // 함수호출
test1(1, 2);     // 함수호출
test1(1, 2, 3);  // 함수호출