/**
 * Created by bagjeongtae on 2017. 7. 16..
 */
var json = {key1: 1, key2: [1,2,3,], key3:{ a: 12}};
console.log(json);

console.log(json['key1'])
console.log(json['key2'])
console.log(json['key3'])
console.log(json['key3']['a'])