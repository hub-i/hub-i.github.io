/**
 * Created by bagjeongtae on 2017. 7. 16..
 */
var a = 'hello world';
var b = "hello world";
var c = 10;
var d = 10 + 1;
var e = c + d;

console.log(a);
console.log(b);
console.log(c);
console.log(d);
console.log(e);