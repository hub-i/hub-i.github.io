/**
 * Created by bagjeongtae on 2017. 7. 16..
 */
console.log('hello world');
console.log("hello world");
console.log(10);
console.log(1 + 1);