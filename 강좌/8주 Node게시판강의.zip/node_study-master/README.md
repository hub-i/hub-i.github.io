# node.js 강의 

해당 프로젝트는 node.js에 대한 강의자료 입니다.

## 주차별 강의 바로가기

[1주차 바로가기](https://github.com/pjt3591oo/node_study/tree/master/1주차)

[2주차 바로가기](https://github.com/pjt3591oo/node_study/tree/master/2주차)

[3주차 바로가기](https://github.com/pjt3591oo/node_study/tree/master/3주차)

[4주차 바로가기](https://github.com/pjt3591oo/node_study/tree/master/4주차)

[5주차 바로가기](https://github.com/pjt3591oo/node_study/tree/master/5주차)

[6주차 바로가기](https://github.com/pjt3591oo/node_study/tree/master/6주차)

[7주차 바로가기](https://github.com/pjt3591oo/node_study/tree/master/7주차)